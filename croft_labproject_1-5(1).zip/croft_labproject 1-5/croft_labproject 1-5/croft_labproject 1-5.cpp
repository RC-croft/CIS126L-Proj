// croft_labproject 1-5.cpp : Defines the entry point for the console application.
//edited for cis126 lab projects 2-5 [original file being unit1_GE3]

#include "stdafx.h"

int addition(int &num1,int &num2,int cans[101]);
int subtraction(int &num1,int &num2,int cans[101]);
int multiplication(int &num1,int &num2,int cans[101]);
int division(int &num1,int &num2,int cans[101]);
int exit(int ttlprobs[101],int cans[101]);

int main()
{
	int difficulty,rand_num,num1,num2,ttlprobs[101], cans[101];
	char response;
	
	RAND_MAX;
	srand(time(0));
	rand_num=(rand()%RAND_MAX)+1;
	do{
		printf("----------------------------------------------\n");
		printf("Math Practice Main Menu\n");
		printf("\n 1. Addition \n");
		printf("\n 2. Subtraction \n");
		printf("\n 3. Division \n");
		printf("\n 4. Multiplication \n");
		printf("\n 5. Exit \n");
		printf("\nselect an option. a, s, d, m or e to choose: ");
		scanf_s(" %c", &response);
		if(response=='e')
		{
		break;
		}
		printf ("please choose a difficulty 3-hard 2-medium 1-easy: ");
		scanf_s("%d", &difficulty);
			if( difficulty == 1)
			{
			 num1=rand()%10+1;
			 num2=rand()%10+1;
			}
			else
			if (difficulty == 2)
			{
			num1=rand()%100+1;
			num2=rand()%100+1;
			}
			else
			{
			 num1=rand()%1000+1;
			 num2=rand()%1000+1;
			}           
			switch (response)
			{
			case 'a': addition(num1,num2,cans);
				ttlprobs+1;
				break;
			case 's': subtraction(num1,num2,cans);
				ttlprobs+1;
				break;
			case 'm':multiplication(num1,num2,cans);
				ttlprobs+1;
				break;
			case 'd':division(num1,num2,cans);
				ttlprobs+1;
				break;
			}
		}
	while(response!='e');
	exit(ttlprobs,cans);
}
int addition(int &num1,int &num2,int cans[101])
{
	
	int answer,counter,num3;
	for(counter=0;counter<3;counter++)
		{
			printf("\n%d+%d=? ",num1,num2);
			scanf_s("%d", &answer);
			num3=num1+num2;
			if (answer == num3)
			{
				printf("correct!\n");
				cans+1;
				break;
			}
		else
		{
			puts("incorrect.\n");
		}
	}
	return cans[101];
}
int subtraction(int &num1,int &num2,int cans[101])
{
	
	int answer,counter,num3;
	for(counter=0;counter<3;counter++)
	{
		printf("\n%d-%d=? ",num1,num2);
		scanf_s("%d", &answer);
		num3=num1-num2;
		if (answer == num3)
		{
			puts("correct!\n");
			cans+1;
			break;
		}
		else
		{
			puts("incorrect.\n");
		}
	}
	return cans[101];
}
int multiplication(int &num1,int &num2,int cans[101])
{
	
	int answer,counter,num3;
	for(counter=0;counter<3;counter++)
	{
		printf("\n%d*%d ",num1,num2);
		scanf_s("%d", &answer);
		num3=num1*num2;
		if (answer == num3)
		{
			puts("correct\n");
			cans+1;
			break;
		}
		else
		{
			puts("incorrect\n");
		}
	}
	return cans[101];
}
int division(int &num1,int &num2,int cans[101])
{
	
	int answer,counter,num3;
	
	for(counter=0;counter<3;counter++)
	{
		printf("%d/%d=? ",num1,num2);
		scanf_s("%d", &answer);
		num3=num1/num2;
		if (answer == num3)
		{
			puts("correct!\n");
			cans+1;
			break;
		}
		else
		{
			puts("incorrect.\n");
		}
	}
	return cans[101];
}

int exit(int ttlprobs[101],int cans[101])
{
	int newcans;
	
	printf("\nyou attempted %d problems and got %d correct\n",ttlprobs,cans);
	newcans=cans[101]/cans[100]*100;
	printf("for a percentage correct of %.2d%\n",newcans);
	return 0;
}